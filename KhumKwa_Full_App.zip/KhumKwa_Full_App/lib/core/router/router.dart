import 'package:go_router/go_router.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:khum_kwa/features/compare/ui/compare_screen.dart';
import 'package:khum_kwa/features/result/ui/result_screen.dart';
import 'package:khum_kwa/features/history/ui/history_screen.dart';
import 'package:khum_kwa/features/compare/models/comparison_result.dart';
part 'router.g.dart';
@riverpod
GoRouter router(RouterRef ref) => GoRouter(routes: [
  GoRoute(path: '/', builder: (c, s) => const CompareScreen()),
  GoRoute(path: '/result', builder: (c, s) => ResultScreen(result: s.extra as MultiComparisonResult)),
  GoRoute(path: '/history', builder: (c, s) => const HistoryScreen()),
]);