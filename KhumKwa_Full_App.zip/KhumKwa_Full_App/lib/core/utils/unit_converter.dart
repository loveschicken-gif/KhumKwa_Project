import 'package:khum_kwa/features/compare/models/product.dart';
class UnitConverter {
  static double getNormalizedQuantity(double q, ProductUnit u) => (u == ProductUnit.kg || u == ProductUnit.l) ? q * 1000 : q;
  static bool areCompatible(ProductUnit a, ProductUnit b) {
    const w = {ProductUnit.g, ProductUnit.kg};
    const v = {ProductUnit.ml, ProductUnit.l};
    if (w.contains(a) && w.contains(b)) return true;
    if (v.contains(a) && v.contains(b)) return true;
    return a == b;
  }
  static String baseUnitLabel(ProductUnit u) {
    if (u == ProductUnit.g || u == ProductUnit.kg) return 'กรัม';
    if (u == ProductUnit.ml || u == ProductUnit.l) return 'มล.';
    return 'ชิ้น';
  }
}