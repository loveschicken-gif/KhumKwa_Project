import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:khum_kwa/features/compare/models/product.dart';
part 'comparison_provider.g.dart';
@riverpod
class ComparisonListNotifier extends _$ComparisonListNotifier {
  @override
  List<Product> build() => [Product(), Product()];
  void add() { if (state.length < 4) state = [...state, Product(unit: state.first.unit)]; }
  void remove(int i) { if (state.length > 2) { var l = [...state]; l.removeAt(i); state = l; } }
  void update(int i, Product p) { var l = [...state]; l[i] = p; state = l; }
  void reset() => state = [Product(), Product()];
}