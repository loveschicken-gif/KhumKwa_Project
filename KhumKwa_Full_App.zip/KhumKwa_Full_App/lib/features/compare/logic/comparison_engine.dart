import 'package:khum_kwa/features/compare/models/product.dart';
import 'package:khum_kwa/features/compare/models/comparison_result.dart';
import 'package:khum_kwa/core/utils/unit_converter.dart';

class ComparisonEngine {
  static const double _tolerance = 0.0001;
  static MultiComparisonResult calculate(List<Product> products) {
    if (products.length < 2) throw Exception('ต้องมีอย่างน้อย 2 รายการ');
    final List<String> labels = ['A', 'B', 'C', 'D'];
    List<RankedProduct> results = [];
    
    // Calculate unit prices
    var data = List.generate(products.length, (i) {
      var p = products[i];
      var normQty = UnitConverter.getNormalizedQuantity(p.quantity, p.unit) * p.promoQuantity;
      return {'uPrice': p.price / normQty, 'label': labels[i], 'product': p, 'normQty': normQty};
    });

    data.sort((a, b) => (a['uPrice'] as double).compareTo(b['uPrice'] as double));
    double bestPrice = data.first['uPrice'] as double;
    bool tie = data.length > 1 && ((data[1]['uPrice'] as double) - bestPrice).abs() < _tolerance;

    for (int i = 0; i < data.length; i++) {
      var item = data[i];
      double uPrice = item['uPrice'] as double;
      results.add(RankedProduct(
        product: item['product'] as Product,
        label: item['label'] as String,
        unitPrice: uPrice,
        percentMoreExpensiveThanBest: ((uPrice - bestPrice) / bestPrice) * 100,
        extraCostVsBest: (item['product'] as Product).price - (bestPrice * (item['normQty'] as double)),
        rank: i + 1,
        isBest: (uPrice - bestPrice).abs() < _tolerance,
      ));
    }
    return MultiComparisonResult(rankedProducts: results, bestProduct: results.first, hasTie: tie);
  }
}