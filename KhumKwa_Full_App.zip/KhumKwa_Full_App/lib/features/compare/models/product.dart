import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
part 'product.g.dart';

@HiveType(typeId: 0)
enum ProductUnit { @HiveField(0) g, @HiveField(1) kg, @HiveField(2) ml, @HiveField(3) l, @HiveField(4) piece }

@HiveType(typeId: 1)
class Product extends HiveObject {
  @HiveField(0) final String id;
  @HiveField(1) double price;
  @HiveField(2) double quantity;
  @HiveField(3) ProductUnit unit;
  @HiveField(4) int promoQuantity;

  Product({String? id, this.price = 0, this.quantity = 0, this.unit = ProductUnit.piece, this.promoQuantity = 1}) : id = id ?? const Uuid().v4();

  Product copyWith({double? price, double? quantity, ProductUnit? unit, int? promoQuantity}) {
    return Product(id: id, price: price ?? this.price, quantity: quantity ?? this.quantity, unit: unit ?? this.unit, promoQuantity: promoQuantity ?? this.promoQuantity);
  }
}

@HiveType(typeId: 2)
class ComparisonHistory extends HiveObject {
  @HiveField(0) final String id;
  @HiveField(1) final List<Product> products;
  @HiveField(2) final DateTime createdAt;
  @HiveField(3) bool isFavorite;

  ComparisonHistory({String? id, required this.products, required this.createdAt, this.isFavorite = false}) : id = id ?? const Uuid().v4();
}