import 'package:khum_kwa/features/compare/models/product.dart';
class RankedProduct {
  final Product product;
  final String label;
  final double unitPrice;
  final double percentMoreExpensiveThanBest;
  final double extraCostVsBest;
  final int rank;
  final bool isBest;
  RankedProduct({required this.product, required this.label, required this.unitPrice, required this.percentMoreExpensiveThanBest, required this.extraCostVsBest, required this.rank, required this.isBest});
}
class MultiComparisonResult {
  final List<RankedProduct> rankedProducts;
  final RankedProduct bestProduct;
  final bool hasTie;
  MultiComparisonResult({required this.rankedProducts, required this.bestProduct, required this.hasTie});
}